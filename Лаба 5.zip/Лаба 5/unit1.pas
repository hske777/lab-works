unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { Tfmain }

  Tfmain = class(TForm)
    bSave: TButton;
    bRead: TButton;
    bClear: TButton;
    ButtonCopy: TButton;
    ComboBox1: TComboBox;
    EditCity: TEdit;
    ListBox1: TListBox;
    Memo1: TMemo;
    procedure bClearClick(Sender: TObject);
    procedure bReadClick(Sender: TObject);
    procedure bSaveClick(Sender: TObject);
    procedure ButtonCopyClick(Sender: TObject);
    procedure ComboBox1Change(Sender: TObject);
    procedure ListBox1Click(Sender: TObject);
  private

  public

  end;

var
  fmain: Tfmain;

implementation

{$R *.lfm}

{ Tfmain }

procedure TfMain.bSaveClick(Sender: TObject);
begin
  Memo1.Lines.SaveToFile('MyText.txt');
end;

procedure TfMain.ButtonCopyClick(Sender: TObject);
var
  i: integer;
begin
  ComboBox1.Clear;                     // очищаем выпадающий список
  for i := 0 to ListBox1.Count - 1 do
    if ListBox1.Selected[i] then       // если строка выделена
      ComboBox1.Items.Add(ListBox1.Items.Strings[i]);

  if ComboBox1.Items.Count > 0 then
  begin
    ComboBox1.ItemIndex := 0;          // выделяем первый добавленный город
    EditCity.Text := ComboBox1.Items.Strings[0];
  end
  else
  begin
    ComboBox1.ItemIndex := -1;
    EditCity.Text := '';
  end;
end;

procedure TfMain.ComboBox1Change(Sender: TObject);
begin
  if ComboBox1.ItemIndex >= 0 then
    EditCity.Text := ComboBox1.Items.Strings[ComboBox1.ItemIndex]
  else
    EditCity.Text := '';
end;

procedure Tfmain.ListBox1Click(Sender: TObject);
begin

end;

procedure TfMain.bReadClick(Sender: TObject);
begin
  if FileExists('MyText.txt') then
    Memo1.Lines.LoadFromFile('MyText.txt')
  else
    ShowMessage('Файл MyText.txt не существует');
end;

procedure TfMain.bClearClick(Sender: TObject);
begin
  Memo1.Clear;  // или Memo1.Lines.Clear;
end;

end.

